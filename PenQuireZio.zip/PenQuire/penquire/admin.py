from django.contrib import admin

# Register your models here.
from .models import *
# Register your models here.

@admin.register(profile)
class ProfileAdmin(admin.ModelAdmin):
    pass

@admin.register(Blog)
class BlogAdmin(admin.ModelAdmin):
    pass

@admin.register(Trending_blogs)
class Trending_blogsAdmin(admin.ModelAdmin):
    pass

@admin.register(Popular_users)
class Popular_usersAdmin(admin.ModelAdmin):
    pass

@admin.register(Ad)
class Ads(admin.ModelAdmin):
    pass

@admin.register(Comments)
class Comments(admin.ModelAdmin):
    pass

@admin.register(Notifications)
class Notifications(admin.ModelAdmin):
    pass
