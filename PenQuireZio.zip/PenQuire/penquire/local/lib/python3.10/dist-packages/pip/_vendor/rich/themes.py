from .default_styles import DEFAULT_STYLES
from .theme import Theme


DEFAULT = Theme(DEFAULT_STYLES)
