from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class profile(models.Model):
    user = models.OneToOneField(User, null=False, on_delete=models.CASCADE)
    verified = models.BooleanField(default=False)
    bio = models.TextField(default="")
    image_url = models.URLField(blank=True, null=True)  # Add this field to store image URL
    lvl = models.IntegerField(default=0)

    def __str__(self):
        return str(self.user)



class Blog(models.Model):
    title = models.TextField()
    username = models.ForeignKey(User, null=True, on_delete=models.CASCADE)
    description = models.TextField()
    Category = models.TextField(null=True)
    content = models.TextField(null=True, default="{{blog.title}}")
    created_at = models.DateField(auto_now_add=True)

    def __str__(self):
        return str(self.id)
class Comments_reply(models.Model):
    text = models.TextField()
    sender = models.TextField()
    time = models.DateField(auto_now_add=True)

class Comments(models.Model):
    text = models.TextField()
    sender = models.ForeignKey(profile, on_delete=models.CASCADE)
    time = models.DateField(auto_now_add=True)
    for_b = models.ForeignKey(Blog, on_delete=models.CASCADE, null=True, default=None)
    # reply = models.ForeignKey(Comments_reply, on_delete=models.CASCADE)


class Trending_blogs(models.Model):
    blog = models.ForeignKey(Blog, on_delete=models.CASCADE)
class Popular_users(models.Model):
    user = models.ForeignKey(profile, on_delete=models.CASCADE )


class Ad(models.Model):
    company = models.TextField()
    link = models.TextField()
    img_link = models.TextField()


class Notifications(models.Model):
    message = models.TextField()
    sender = models.ForeignKey(profile, on_delete=models.CASCADE)
    is_read = models.BooleanField(default=False)
    for_user = models.ForeignKey(User, on_delete=models.CASCADE)
