document.addEventListener("DOMContentLoaded", function() {
    var showFullscreenButton = document.getElementById("menu");
    var fullscreenOverlay = document.getElementById("fullscreenOverlay");

    showFullscreenButton.addEventListener("click", function() {
        if (fullscreenOverlay.style.display === "none" || fullscreenOverlay.style.display === "") {
            fullscreenOverlay.style.display = "block";


            setTimeout(function() {
                fullscreenOverlay.style.transform = "translateX(0)";
            }, 50); // Adding a slight delay for smoother transition
        } else {
            fullscreenOverlay.style.transform = "translateX(-100%)";
            fullscreenOverlay.addEventListener("transitionend", function() {
                fullscreenOverlay.style.display = "none";
            }, { once: true });
        }
    });

});
