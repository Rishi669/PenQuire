const $upload = $('#upload'),
      $crop = $('#crop'),
      $result = $('#result'),
      $croppie = $('#croppie');
      $next = $('#next');

var cr,
    cr_img = '',
    img_w = 320,
    img_h = 320,
    isCrop = 0;

// Check if file upload is supported
$(function(){
  if (window.File && window.FileList && window.FileReader)
    fileInit();
  else
    alert('Your device does not support image upload');
});

// File select/drop functionality
var fileselect = document.getElementById("fileselect"),
    filedrag = document.getElementById("filedrag");

function fileInit(){
  // File select
  fileselect.addEventListener("change", FileSelectHandler, false);
  // Is XHR2 available?
  var xhr = new XMLHttpRequest();
  // File drop
  if (xhr.upload) {
    filedrag.addEventListener("dragover", FileDragHover, false);
    filedrag.addEventListener("dragleave", FileDragHover, false);
    filedrag.addEventListener("drop", FileSelectHandler, false);
  }
}

// File selection handler
function FileSelectHandler(e) {
  // Cancel event and hover styling
  FileDragHover(e);
  // Fetch FileList object
  var files = e.target.files || e.dataTransfer.files;
  if(files[0] && files[0].type.match('image.*')){
    var reader = new FileReader();
    reader.onload = function (e) {
      $upload.hide();
      if(cr_img == '') { // First upload
        cr_img = e.target.result;
        cropInit();
      }
      else {// Bind photo
        cr_img = e.target.result;
        bindCropImg();
      }
      $crop.fadeIn(300);
      
    }
    reader.readAsDataURL(files[0]);
  }
}

// File drag hover effect
function FileDragHover(e) {
  e.stopPropagation();
  e.preventDefault();
  filedrag.className = (e.type == "dragover" ? "hover" : "");
}

// Crop settings
function cropInit(){
  cr = $croppie.croppie({
    viewport: {
      width: img_w,
      height: img_h
    },
    boundary: {
      width: img_w,
      height: img_h
    },
    mouseWheelZoom: false,
    enableOrientation: true
  });

  bindCropImg();
}

// Bind image
function bindCropImg() {
  cr.croppie('bind', {
    url: cr_img
  });
}

// Image cropping
function cropResult() {
  if(!isCrop){
    isCrop = 1;
    cr.croppie('result', {
      type: 'canvas', // canvas(base64)|html
      size: {width:img_w, height:img_h}, //'viewport'|'original'|{width:500, height:500}
      format: 'jpeg', //'jpeg'|'png'|'webp'
      quality: 1 //0~1
    }).then(function (resp) {
      $crop.hide();
      $result.find('img').attr('src', resp);
      $result.fadeIn(300);
      document.getElementById("base64").value = resp;
    });
  }
}
