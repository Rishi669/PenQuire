from django.urls import path
from .views import (
    home,
    signup,
    login_user,
    logout_user,
    upload,
    blog_detail,
    # product_detail
    # editor,
    details,
    users_profile,
    upload_image,
    profile_edit,
    search,
    search_results,
    remove_profile_pic,
    editorMain,
    delete_blog,
    edit_blog_page,
    notification_list,
    mark_as_read,
    delete_echo,
    help
)

urlpatterns = [
    path('', home, name='home'),
    path('signup/', signup, name='signup'),
    path('login/', login_user, name='login_user'),
    path('logout/', logout_user, name='logout_user'),
    path('studio/', upload, name='upload'),
    # path('editor/', editor, name='editor'),
    path('editor/<int:blog_id>/', editorMain, name='editorMain'),
    path('blog/<int:blog_id>/', blog_detail, name='blog_detail'),
    path('details', details, name='details'),
    path('user/<slug:username>/', users_profile, name='users_profile'),
    path('upload_profilepic/', upload_image, name="upload_image"),
    path('profile/', profile_edit, name="profile_edit"),
    path('search/', search, name='search'),
    path('search-r/<str:query>/', search_results, name='search_results'),
    path('rpppath/', remove_profile_pic, name='remove_profile_pic'),
    path('delete/blog/<int:blog_id>/', delete_blog, name='delete_blog'),
    path('edit/blog/<int:blog_id>/', edit_blog_page, name='edit_blog_page'),
    path('notifications', notification_list, name='notification_list'),
    path('mark_as_read/<int:pk>/',mark_as_read, name='mark_as_read'),
    path('delete_echo/<int:pk>/',delete_echo, name='delete_echo'),

    path('help/',help, name='help'),


]
