from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse, JsonResponse
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from .models import Blog, profile  # Assuming the profile model is imported correctly
import pyrebase
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from markdown2 import markdown
from django.utils.safestring import mark_safe
from firebase_admin import storage as admin_storage, credentials, firestore
import firebase_admin
from urllib.parse import urlparse, unquote
from django.core.files.base import ContentFile
import base64
from PIL import Image
import io
from .models import *
# Initialize Firebase Admin SDK
cred = credentials.Certificate('config/key.json')
firebase_admin.initialize_app(cred, {'storageBucket': 'penquire-project.appspot.com'})

# Pyrebase Configuration
config = {
  'apiKey': "AIzaSyDN-wVgGyNaZy6cfQIzeEta1qXWPEbiByw",
  'authDomain': "penquire-project.firebaseapp.com",
  'projectId': "penquire-project",
  'storageBucket': "penquire-project.appspot.com",
  'messagingSenderId': "222906223888",
  'appId': "1:222906223888:web:25b3cb950e89c86d8f2995",
  'databaseURL': ""
};
firebase = pyrebase.initialize_app(config)
storage = firebase.storage()

def signup(request):
    if request.user.is_authenticated:
        return redirect('home')

    newusern = None
    newlyemail = None
    error = None

    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')

        if User.objects.filter(username=username).exists():
            newusern = 'no'
        elif User.objects.filter(email=email).exists():
            newlyemail = 'no'
        else:
            try:
                validate_password(password)
            except ValidationError as e:
                error = e.messages[0]

            if password != confirm_password:
                error = 'Passwords do not match'
            elif error is None:
                # Hash the password
                hashed_password = make_password(password)

                # Create and save the user

                user = User.objects.create(username=username, email=email, password=hashed_password)
                profile.objects.create(user=user)
                penquire = get_object_or_404(profile, user__username="penquire")
                Notifications.objects.create(sender=penquire, for_user=user, message="Welcome! We hope you enjoy this platform, and we're here to assist you in achieving success.")

                # Continue with the login logic
                login(request, user)

                return redirect('home')

    return render(request, 'signup.html', {'newusern': newusern, 'newlyemail': newlyemail, 'error': error})


def login_user(request):
    if request.user.is_authenticated:
        return redirect('home')

    usernameisvalid = True
    passwordisvalid = True

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')


        # Use Django's authenticate function to check username and password
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            usernameisvalid = False
            passwordisvalid = False

    return render(request, 'login.html', {'usernameisvalid': usernameisvalid, 'passwordisvalid': passwordisvalid})

@login_required
def details(request):
    user = request.user
    if request.method == 'POST':
        title = request.POST.get('title')
        description = request.POST.get('description')
        title = mark_safe(title)
        tags = request.POST.get('tags')
        content = "<p>Write..</p>"
        blog = Blog.objects.create(title=title, username=user, description=description, content=content, Category=tags)
        new_blog_id = blog.id
        return redirect('editorMain', blog_id = new_blog_id)
    return render(request, 'details.html')


# @login_required
# def editor(request):
#     user = request.user
#     blogs = Blog.objects.filter(username=user)
#     if request.method == 'POST':
#         form_name = request.POST['submit_form']
#         if form_name == 'form1':
#             content = request.POST.get('content')
#             title = "Title"
#             description = ""
#             new_blog = Blog.objects.create(content=content, title=title, username=user, description=description)
#             new_blog_id = new_blog.id
#             return redirect('editor', blog_id = new_blog_id)

#     return render(request, 'editor.html', {'blogs': blogs})

@login_required
def editorMain(request, blog_id):
    user = request.user
    blog = get_object_or_404(Blog, pk=blog_id)
    blog.content = mark_safe(blog.content)
    if blog.username == user:
        if request.method == 'POST':
                content = request.POST.get('content')
                blog.content = content
                blog.save()
                # id = blog.id
                return redirect('editorMain', blog_id=blog_id)
    else:
        return redirect('home')
    return render(request, 'editorMain.html', {'blog': blog})

    # return HttpResponse("PUBLISHED") # Return a JSON response indicating success # Return error for unsupported request method
def blog_detail(request, blog_id):
    user = request.user
    blog = get_object_or_404(Blog, pk=blog_id)
    blog.content = mark_safe(blog.content)
    blogAuthor = blog.username
    user_profile = profile.objects.get(user=blogAuthor)
    comments = Comments.objects.filter(for_b = blog)
    if request.method=='POST':
        text = request.POST.get('text')
        user_pro=user.profile
        Comments.objects.create(sender = user_pro, text=text, for_b=blog)
    return render(request, 'blog.html', {'blog': blog, 'user_profile': user_profile, 'user':user, 'comments':comments})

from django.core.paginator import Paginator
import random

def home(request):
    blogs = Blog.objects.all()
    if request.user.is_authenticated:
        current_user = request.user
        # Fetch all blogs excluding the current user's blogs
        blogs = Blog.objects.exclude(username=current_user)
    # Shuffle blogs
    blogs = list(blogs)
    random.shuffle(blogs)

    # Paginate blogs
    paginator = Paginator(blogs, 12)  # Show 12 blogs per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    # Fetch profiles and ads
    profiles = profile.objects.all()  # Ensure your model name is correct
    ads = Ad.objects.all()  # Fetch ads
    if request.user.is_authenticated:
        unread_count = Notifications.objects.filter(for_user=request.user, is_read=False).count()
    else:
        unread_count = 0
    # Render the template with the context
    return render(request, 'home.html', {'page_obj': page_obj, 'profiles': profiles,'ads':ads, 'unread_count':unread_count })
@login_required
def upload(request):
    user = request.user
    blogs = Blog.objects.filter(username=user)

    return render(request, 'upload.html', {'blogs': blogs})




@login_required
def logout_user(request):
    logout(request)
    return redirect('home')

def users_profile(request, username):
    userd = get_object_or_404(User, username=username)
    user_current = request.user
    if user_current.username == username:
        return redirect('profile_edit')
    user_profile = profile.objects.get(user=userd)
    blogs = Blog.objects.filter(username=userd).order_by("-created_at")
    if request.method=='POST':
        cu_pro = get_object_or_404(profile, user=user_current)

        message = request.POST.get("message")
        Notifications.objects.create(message=message, for_user=userd, sender=cu_pro)
    return render(request, 'user_profile.html', {'userd': userd, 'user_profile': user_profile, 'blogs':blogs, 'user_current':user_current})



def get_name_from_url(image_url):
    # Parse the URL
    parsed_url = urlparse(image_url)

    # Get the path component of the URL
    path = parsed_url.path

    # Split the path by '/'
    path_components = path.split('/')

    # The last component should be the image name
    image_name = path_components[-1]
    image_name = unquote(image_name)
    return image_name

from PIL import Image
import io
@login_required
def upload_image(request):
    if request.method == 'POST' and request.POST.get("base64str"):
        base64str = request.POST.get("base64str").split(",")[-1]  # Extract the base64 part of the string
        profile_obj = profile.objects.get(user=request.user)
        user = request.user
        username = user.username
        bucket = admin_storage.bucket()

        # Decode base64 string to image bytes
        image_data = base64.b64decode(base64str)
        img = Image.open(io.BytesIO(image_data))

        # Crop the image (adjust the coordinates as per your requirement)
        # cropped_img = img.crop((0, 0, 100, 100))  # Example: Cropping first 100x100 pixels

        # Save the cropped image to a BytesIO object
        cropped_img_io = io.BytesIO()
        img.save(cropped_img_io, format='JPEG')  # You can adjust the format as needed

        # Reset the BytesIO object to the beginning of the stream
        cropped_img_io.seek(0)

        # Delete existing image if it exists
        image_url_which_exists = profile_obj.image_url
        if image_url_which_exists:
            image_name = get_name_from_url(image_url_which_exists)
            blob = bucket.blob(f'{image_name}')
            blob.delete()

        try:
            filename = f"profile_images/{request.user.username}/img.jpg"
            storage.child(filename).put(cropped_img_io)

            # Get the URL of the uploaded image
            image_url = storage.child(filename).get_url(None)

            # Save the image URL in the user's profile
            profile_obj.image_url = image_url
            profile_obj.save()

            return redirect('profile_edit')  # Redirect to profile page after upload
        except Exception as e:
            print(f"Error uploading new image to Firebase Storage: {e}")

    return render(request, 'upload_image.html')


@login_required
def profile_edit(request):
    userr = request.user
    user_profile = profile.objects.get(user=userr)
    if request.method =="POST":
        bio = request.POST.get("bio")
        user_profile.bio = bio
        user_profile.save()


    userr = request.user
    blogs = Blog.objects.filter(username=userr).order_by("-created_at")
    return render(request, 'profile_edit.html', {'blogs': blogs, 'userr':userr, 'user_profile': user_profile})


# def search(request):
#     if request.method == 'POST':
#         query = request.POST.get('search-q', '')
#         return redirect('search_results', query=query)
#     return render(request, 'search.html')

def search(request):
    blogss = Trending_blogs.objects.all()
    popularr = Popular_users.objects.all()
    if request.method == 'POST':
        query = request.POST.get('search-q', '')
        return redirect('search_results', query=query)


    return render(request, 'search.html', {'blogss': blogss, 'popularr':popularr})

def search_results(request, query):
    if request.method == 'POST':
        query = request.POST.get('search-q', '')
        return redirect('search_results', query=query)

    try:
        all_profiles = profile.objects.filter(user__username__icontains=query)
        all_posts = Blog.objects.filter(title__icontains=query) | Blog.objects.filter(content__icontains=query) | Blog.objects.filter(username__username__icontains=query)

        if not all_posts.exists() and not all_profiles.exists():
            error = "No matching results found."
            return render(request, 'search-match.html', {'error': error, 'query': query})

        context = {
            'allPosts': all_posts,
            'allProfiles': all_profiles,
            'query': query,
        }

        return render(request, 'search-match.html', context)
    except Exception as e:
        error = f"An error occurred: {str(e)}"
        return render(request, 'search-match.html', {'error': error, 'query': query})

@login_required
def remove_profile_pic(request):
    user = request.user
    user_profile = profile.objects.get(user=user)
    # Delete the current profile picture from storage
    image_url_which_exists = user_profile.image_url
    if image_url_which_exists:
        image_name = get_name_from_url(image_url_which_exists)
        bucket = admin_storage.bucket()
        blob = bucket.blob(image_name)
        blob.delete()
    # Set the image URL in the user's profile to None
    user_profile.image_url = None
    user_profile.save()
    return redirect('profile_edit')  # Or wherever you want to redirect after removal


@login_required
def delete_blog(request, blog_id):
    blog = get_object_or_404(Blog, pk=blog_id)
    user = request.user
    if blog.username == user:
        if request.method=="POST":
            sure = request.POST.get("sure")
            if sure == "yes":
                blog.delete()
            else:
                return redirect("delete_blog", blog_id)
            return redirect('profile_edit')
    else:
        return redirect("home")
    return render(request, "delete_blog.html", {'blog':blog})


@login_required
def edit_blog_page(request, blog_id):
    blog = get_object_or_404(Blog, pk=blog_id)
    user = request.user
    if blog.username == user:
        if request.method=="POST":
            title=request.POST.get("title")
            description = request.POST.get("desc")
            blog.title=title
            blog.description=description
            blog.save()
    else:
        return redirect("home")
    return render(request, "edit_blog_page.html", {'blog':blog})


@login_required
def notification_list(request):

    notifications = Notifications.objects.filter(for_user=request.user)
    return render(request, 'notification_list.html', {'notifications': notifications})

@login_required
def mark_as_read(request, pk):
    notification = get_object_or_404(Notifications, pk=pk, for_user=request.user)
    notification.is_read = True
    notification.save()
    return redirect('notification_list')

@login_required
def delete_echo(request, pk):
    notification = get_object_or_404(Notifications, pk=pk, for_user=request.user)
    notification.delete()
    return redirect('notification_list')

def unread_notification_count(request):
    if request.user.is_authenticated:
        unread_count = UserNotification.objects.filter(user=request.user, is_read=False).count()
    else:
        unread_count = 0
    return {'unread_notification_count': unread_count}

def help(request):
    return render(request, "help.html")
